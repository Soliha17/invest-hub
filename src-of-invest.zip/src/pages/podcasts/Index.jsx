import React from "react";

function Podcasts() {
  return <div>Podcasts</div>;
}

export default Podcasts;
