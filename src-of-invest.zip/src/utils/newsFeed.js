import watchIcon from "../assets/icons/watch-icon.svg"
import fireIcon from "../assets/icons/fire-icon.svg"
import savedIcon from "../assets/icons/saved-icon.svg"
export const newsFeedLinks = [
  {
    id: 1,
    img: watchIcon,
    title: "Oxirgilar",
  },
  {
    id: 2,
    img: fireIcon,
    title: "Mashhurlar",
  },
  {
    id: 3,
    img: savedIcon,
    title: "Saqlanganlar",
  },
];